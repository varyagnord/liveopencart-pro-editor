# 🚀 LiveOpenCart Pro Editor

Версия: v1.0.5

## ✨ Фишки
- 🤖 **AI Assistant**
- ❝ **Smart Quote**
- 🎨 **Syntax Highlighting**

## 📦 Установка
1. Скачайте архив `liveopencart_assistant.zip`.
2. Распакуйте.
3. В `chrome://extensions/` включите режим разработчика.
4. Нажмите 'Load unpacked'.
