# 🚀 LiveOpenCart Pro Editor

Версия: v1.0.4

## ✨ Фишки
- 🤖 AI Assistant
- ❝ Smart Quote
- 🎨 Syntax Highlighting
